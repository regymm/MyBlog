// #1: simplest assignment
`timescale 1ns / 1ps
 
module top(
    input clk,
	output [1:0]o
    );
    assign o[0] = clk;
    assign o[1] = clk;
endmodule

