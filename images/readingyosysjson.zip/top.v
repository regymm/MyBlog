// #1: simplest assignment
`timescale 1ns / 1ps
 
module top(
    input clk,
    input i,
	output o
    );
    //assign o[0] = clk;
    //assign o[1] = clk;
    always @ (posedge clk) begin
        o <= i;
    end
endmodule

